<!DOCTYPE html>
<html>
<head>
<title>multiplication</title>
<script language="javascript">
function mul()
{
 var num=parseInt(document.f1.n1.value);
 var i=0;
 for(i=1;i<=10;i++)
{
 document.writeln("<br>"+num+ "X" +i+ "=" +(num*i));
}
}
 </script>
 </head>
 <body>
 <form name="f1">
 <h1>Multiplication Table</h1>
 Enter Number:
 <input type="text" name="n1">
 <input type="button" value="print table" onclick="mul()">
 </form>
 </body>
 </html>